package com.syncstream.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

// ============================================================
//  FileUtil — Saving chat logs and session reports
// ============================================================
public class FileUtil {

    private static final String REPORTS_DIR = "reports/";

    /**
     * Saves a chat log string to a .txt file in the /reports folder.
     * Returns the path where it was saved.
     *
     * EXAMPLE:
     *   saveChatLog(42, "Alice: Hello\nBob: Hi")
     *   → saves to "reports/chat_room42_2025-05-04_14-30.txt"
     */
    public static String saveChatLog(int roomId, String logContent) {
        try {
            Files.createDirectories(Paths.get(REPORTS_DIR));  // make folder if needed

            String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm"));
            String filename = REPORTS_DIR + "chat_room" + roomId + "_" + timestamp + ".txt";

            Files.writeString(Paths.get(filename), logContent);
            System.out.println("[FileUtil] Chat log saved: " + filename);
            return filename;
        } catch (IOException e) {
            System.err.println("[FileUtil] saveChatLog error: " + e.getMessage());
            return null;
        }
    }

    /**
     * Generates and saves a session report as a text file.
     * Includes room info, participants, and watch durations.
     */
    public static String saveSessionReport(int roomId, String roomName,
                                           List<String> participantSummaries) {
        try {
            Files.createDirectories(Paths.get(REPORTS_DIR));

            String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm"));
            String filename = REPORTS_DIR + "session_room" + roomId + "_" + timestamp + ".txt";

            StringBuilder sb = new StringBuilder();
            sb.append("=== Session Report ===\n");
            sb.append("Room: ").append(roomName).append("\n");
            sb.append("Room ID: ").append(roomId).append("\n");
            sb.append("Generated: ").append(LocalDateTime.now()).append("\n");
            sb.append("\n--- Participants ---\n");
            for (String summary : participantSummaries) {
                sb.append(summary).append("\n");
            }

            Files.writeString(Paths.get(filename), sb.toString());
            System.out.println("[FileUtil] Session report saved: " + filename);
            return filename;
        } catch (IOException e) {
            System.err.println("[FileUtil] saveSessionReport error: " + e.getMessage());
            return null;
        }
    }
}
