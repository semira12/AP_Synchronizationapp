package com.syncstream.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

// ============================================================
//  PasswordUtil — Hashing passwords with SHA-256
// ============================================================
public class PasswordUtil {

    /**
     * Converts a plain text password to a SHA-256 hex string.
     *
     * WHY HASH?
     *   Never store passwords as plain text. If the DB is leaked,
     *   attackers can't recover the original passwords from hashes.
     *
     * EXAMPLE:
     *   hash("password123") → "ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f"
     */
    public static String hash(String plainText) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(plainText.getBytes("UTF-8"));

            // Convert byte array to hex string
            StringBuilder hex = new StringBuilder();
            for (byte b : hashBytes) {
                // format each byte as 2 hex digits
                hex.append(String.format("%02x", b));
            }
            return hex.toString();

        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    /** Quick check — does a plain password match a stored hash? */
    public static boolean verify(String plainText, String storedHash) {
        return hash(plainText).equals(storedHash);
    }
}

