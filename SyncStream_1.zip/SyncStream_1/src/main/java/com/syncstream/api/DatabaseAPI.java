package com.syncstream.api;

import com.syncstream.dao.*; // ParticipantDAO, ChatMessageDAO, WatchHistoryDAO
import com.syncstream.model.*;
import com.syncstream.util.FileUtil;

import java.util.List;

/**
 * DatabaseAPI — The single entry point for all database operations.
 *
 * WHY THIS CLASS?
 *   Person 1 (GUI) and Person 2 (Server) should NOT instantiate DAOs directly.
 *   They call DatabaseAPI.register(), DatabaseAPI.login(), etc.
 *   This keeps the code clean and decoupled.
 *
 * USAGE EXAMPLE (from Person 1's login screen):
 *   User user = DatabaseAPI.login("alice", "password123");
 *   if (user != null) { // show main menu }
 *
 * USAGE EXAMPLE (from Person 2's server):
 *   int historyId = DatabaseAPI.startWatchSession(userId, roomId, videoPath);
 *   // ... when user disconnects:
 *   DatabaseAPI.endWatchSession(historyId, secondsWatched);
 */
public class DatabaseAPI {

    // Instantiate all DAOs once
    private static final UserDAO         userDAO         = new UserDAO();
    private static final RoomDAO         roomDAO         = new RoomDAO();
    private static final ParticipantDAO participantDAO  = new ParticipantDAO();
    private static final ChatMessageDAO chatMessageDAO  = new ChatMessageDAO();
    private static final WatchHistoryDAO watchHistoryDAO = new WatchHistoryDAO();

    // =====================================================
    // USER METHODS
    // =====================================================

    /** Register a new user. Returns user_id or -1 on failure. */
    public static int register(String username, String email, String password) {
        if (userDAO.usernameExists(username)) {
            System.out.println("[API] Username already taken: " + username);
            return -2;   // -2 = username taken (distinct from -1 = DB error)
        }
        return userDAO.registerUser(username, email, password);
    }

    /**
     * Authenticate a user.
     * @return User object if valid, null if wrong credentials.
     */
    public static User login(String username, String password) {
        return userDAO.login(username, password);
    }

    /** Get a user's details by their ID. */
    public static User getUser(int userId) {
        return userDAO.getUserById(userId);
    }

    // =====================================================
    // ROOM METHODS
    // =====================================================

    /**
     * Create a new room.
     * @return room_id of the new room, or -1 on error.
     */
    public static int createRoom(String roomName, int hostUserId, String videoPath) {
        int roomId = roomDAO.createRoom(roomName, hostUserId, videoPath);
        if (roomId > 0) {
            // Automatically add host as a participant with role "host"
            participantDAO.joinRoom(roomId, hostUserId, "host");
        }
        return roomId;
    }

    /**
     * Join a room by its short code (e.g. "A3F9KL").
     * @return the Room object, or null if code not found / room full.
     */
    public static Room joinRoomByCode(String roomCode, int userId) {
        Room room = roomDAO.getRoomByCode(roomCode);
        if (room == null) {
            System.out.println("[API] Room not found: " + roomCode);
            return null;
        }
        int count = participantDAO.getActiveCount(room.getRoomId());
        if (count >= room.getMaxUsers()) {
            System.out.println("[API] Room is full: " + roomCode);
            return null;
        }
        participantDAO.joinRoom(room.getRoomId(), userId, "viewer");
        return room;
    }

    /** Close a room (host ends session). */
    public static boolean closeRoom(int roomId) {
        return roomDAO.closeRoom(roomId);
    }

    /** Get all currently active rooms. */
    public static List<Room> getActiveRooms() {
        return roomDAO.getActiveRooms();
    }

    // =====================================================
    // PARTICIPANT METHODS
    // =====================================================

    /** Record that a user has left a room. */
    public static boolean leaveRoom(int roomId, int userId) {
        return participantDAO.leaveRoom(roomId, userId);
    }

    /** How many users are currently in a room? */
    public static int getParticipantCount(int roomId) {
        return participantDAO.getActiveCount(roomId);
    }

    // =====================================================
    // CHAT METHODS
    // =====================================================

    /**
     * Save a chat message. Called by Person 2's server every time
     * a message is broadcast to a room.
     * @return new message_id
     */
    public static int saveMessage(int roomId, int userId, String message, String msgType) {
        return chatMessageDAO.saveMessage(roomId, userId, message, msgType);
    }

    /** Load all chat messages for a room (history). */
    public static List<ChatMessage> getChatHistory(int roomId) {
        return chatMessageDAO.getMessagesByRoom(roomId);
    }

    /**
     * Export the chat log of a room to a .txt file.
     * @return file path where the log was saved
     */
    public static String exportChatLog(int roomId) {
        String logContent = chatMessageDAO.exportChatLog(roomId);
        return FileUtil.saveChatLog(roomId, logContent);
    }

    // =====================================================
    // WATCH HISTORY METHODS
    // =====================================================

    /**
     * Start tracking a watch session.
     * Call this when user starts watching.
     * @return history_id — save this to call endWatchSession later
     */
    public static int startWatchSession(int userId, int roomId, String videoPath) {
        return watchHistoryDAO.startSession(userId, roomId, videoPath);
    }

    /**
     * End a watch session, recording total seconds watched.
     * Call this when user disconnects or room closes.
     */
    public static boolean endWatchSession(int historyId, int totalSeconds) {
        return watchHistoryDAO.endSession(historyId, totalSeconds);
    }

    /** Get all watch history entries for a user (for analytics display). */
    public static List<WatchHistory> getWatchHistory(int userId) {
        return watchHistoryDAO.getHistoryByUser(userId);
    }
}
