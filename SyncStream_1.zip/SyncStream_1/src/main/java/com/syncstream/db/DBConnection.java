package com.syncstream.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection — Singleton database connection manager.
 *
 * WHY SINGLETON?
 *   We only want ONE connection object to exist for the whole app.
 *   Opening a new Connection every time is slow and can exhaust
 *   the MySQL connection limit quickly.
 *
 * HOW TO USE:
 *   Connection conn = DBConnection.getInstance().getConnection();
 */
public class DBConnection {

    // --- Configuration ---
    private static final String URL      = "jdbc:mysql://localhost:3306/syncstream_db";
    private static final String USER     = "root";        // change to your MySQL user
    private static final String PASSWORD = ""; // change to your password

    // The single instance of this class
    private static DBConnection instance;

    // The actual JDBC connection object
    private Connection connection;

    // Private constructor: no one outside can do "new DBConnection()"
    private DBConnection() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open the connection
            this.connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("[DB] Connected to MySQL successfully.");

        } catch (ClassNotFoundException e) {
            // This means the mysql-connector JAR is missing from your classpath
            System.err.println("[DB] MySQL Driver not found! Add mysql-connector-j.jar to your project.");
            e.printStackTrace();
        } catch (SQLException e) {
            // Wrong URL, user, password, or MySQL is not running
            System.err.println("[DB] Failed to connect: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Returns the single instance of DBConnection.
     * Thread-safe using synchronized keyword.
     */
    public static synchronized DBConnection getInstance() {
        if (instance == null) {
            instance = new DBConnection();
        }
        return instance;
    }

    /**
     * Returns the live Connection object.
     * If it died (network drop, timeout), it reconnects automatically.
     */
    public Connection getConnection() {
        try {
            // isValid(2) pings MySQL with a 2-second timeout
            if (connection == null || !connection.isValid(2)) {
                System.out.println("[DB] Reconnecting...");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
        } catch (SQLException e) {
            System.err.println("[DB] Reconnect failed: " + e.getMessage());
        }
        return connection;
    }

    /** Call this when the app closes to free MySQL resources. */
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("[DB] Connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
