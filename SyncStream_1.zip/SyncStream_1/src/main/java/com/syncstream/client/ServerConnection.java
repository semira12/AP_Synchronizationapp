package com.syncstream.client;

import java.io.*;
import java.net.Socket;
import java.util.function.Consumer;

/**
 * ServerConnection — Client-side wrapper around the TCP socket.
 *
 * FIX: The listener is now replaceable via setListener() so that each
 * screen (Lobby, Room) can register its own handler without needing a
 * new connection. Previously the listener was final, meaning chat/sync
 * messages always went to the LoginController callback (already gone)
 * and never reached the RoomController — causing the "messages only
 * appear after rejoin" bug.
 */
public class ServerConnection {

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    // volatile so the reader thread always sees the latest value
    private volatile Consumer<String> messageListener;
    private volatile boolean running = false;

    public ServerConnection(String host, int port, Consumer<String> listener) throws IOException {
        this.messageListener = listener;
        this.socket = new Socket(host, port);
        this.out = new PrintWriter(new BufferedWriter(
                   new OutputStreamWriter(socket.getOutputStream())), true);
        this.in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.running = true;

        Thread reader = new Thread(this::readLoop, "ServerReader");
        reader.setDaemon(true);
        reader.start();

        System.out.println("[Client] Connected to server at " + host + ":" + port);
    }

    /**
     * Replace the message listener at runtime.
     * Call this whenever the active screen changes so messages are
     * routed to the correct controller.
     */
    public void setListener(Consumer<String> listener) {
        this.messageListener = listener;
    }

    private void readLoop() {
        try {
            String line;
            while (running && (line = in.readLine()) != null) {
                final String msg = line;
                Consumer<String> handler = messageListener;
                if (handler != null) handler.accept(msg);
            }
        } catch (IOException e) {
            if (running) {
                Consumer<String> handler = messageListener;
                if (handler != null) handler.accept("ERROR:Connection lost");
            }
        }
        running = false;
    }

    public void send(String message) {
        if (out != null && running) {
            out.println(message);
        }
    }

    public void disconnect() {
        running = false;
        try {
            if (out != null) out.println("LEAVE");
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException ignored) {}
        System.out.println("[Client] Disconnected from server.");
    }

    public boolean isConnected() {
        return running && socket != null && !socket.isClosed();
    }
}
