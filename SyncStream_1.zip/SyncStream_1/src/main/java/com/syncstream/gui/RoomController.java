package com.syncstream.gui;

import com.syncstream.api.DatabaseAPI;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.util.Duration;

import java.io.File;

/**
 * RoomController — Controller for room.fxml
 *
 * BUGS FIXED:
 *
 * 1. LISTENER NOT WIRED (chat never arrived in real-time):
 *    updateServerHandler() was an empty comment block. Now initialize()
 *    calls session.getConnection().setListener(this::onServerMessage)
 *    so all server messages are routed here immediately.
 *
 * 2. VIDEO NOT VISIBLE (black box, loads but shows nothing):
 *    - MediaView fitWidth/fitHeight were hardcoded; the view wasn't
 *      bound to its parent VBox, so it never resized to fill the pane.
 *    - Fixed: removed hardcoded sizes from FXML and added
 *      mediaView.fitWidthProperty().bind(videoContainer.widthProperty())
 *      so the video fills the available space dynamically.
 *
 * 3. SENDER'S OWN CHAT MESSAGES MISSING:
 *    handleChat() on the server used broadcastToRoom() (includes all)
 *    but also passed `this` — which was the correct include-all call.
 *    However the sender never received it because the server echoes
 *    CHAT back, but the client's listener was the dead LoginController.
 *    Fixed by bug #1 above (correct listener wiring).
 *
 * 4. VIEWER HOST-CONTROLS VISIBILITY:
 *    hostControls was correctly hidden, but seekSlider was always shown
 *    for viewers even though they can't seek. Now the entire timeline
 *    row is disabled for viewers (they can see it but not drag it).
 */
public class RoomController {

    // Video player
    @FXML private MediaView    mediaView;
    @FXML private VBox         videoContainer;   // parent of mediaView — for width binding
    @FXML private Button       playButton;
    @FXML private Button       pauseButton;
    @FXML private Slider       seekSlider;
    @FXML private Label        timeLabel;
    @FXML private HBox         hostControls;
    @FXML private HBox         timelineRow;      // row containing slider — disable for viewers

    // Chat
    @FXML private ListView<String> chatList;
    @FXML private TextField        chatInput;
    @FXML private HBox             reactionBar;

    // Room info
    @FXML private Label roomInfoLabel;
    @FXML private Label participantCountLabel;

    private final SessionState session = SessionState.getInstance();
    private MediaPlayer mediaPlayer;
    private boolean seekSliderDragging = false;

    // =====================================================
    // INITIALIZATION
    // =====================================================
    @FXML
    public void initialize() {
        // Show room info
        roomInfoLabel.setText("Room: " + session.getCurrentRoomName()
                + "  |  Code: " + session.getCurrentRoomCode()
                + "  |  " + (session.isHost() ? "👑 HOST" : "👤 VIEWER"));

        // Host controls (play/pause) only shown for host
        hostControls.setVisible(session.isHost());
        hostControls.setManaged(session.isHost());

        // Viewers can see the timeline but cannot drag it
        if (!session.isHost() && timelineRow != null) {
            timelineRow.setDisable(true);
        }

        // FIX #1: Register this controller as the live message handler.
        // This replaces whatever listener the LobbyController had set.
        session.getConnection().setListener(this::onServerMessage);

        // Load video
        loadVideo(session.getCurrentVideoPath());

        // Load chat history from DB
        loadChatHistory();

        // Update participant count
        updateParticipantCount();
    }

    private void loadVideo(String videoPath) {
        if (videoPath == null || videoPath.isBlank()) {
            addSystemMessage("No video path specified.");
            return;
        }

        try {
            File f = new File(videoPath);
            if (!f.exists()) {
                addSystemMessage("Video file not found: " + videoPath);
                return;
            }

            Media media = new Media(f.toURI().toString());
            mediaPlayer = new MediaPlayer(media);
            mediaView.setMediaPlayer(mediaPlayer);

            // FIX #2: Bind MediaView dimensions to its parent container
            // so the video actually fills the available space.
            // Without this, MediaView uses its own preferred size (or 0×0)
            // and renders nothing visible even though the player is working.
            if (videoContainer != null) {
                mediaView.fitWidthProperty().bind(videoContainer.widthProperty());
                // Height is controlled by preserveRatio=true in FXML
            }

            // Keep seek slider in sync with playback position
            mediaPlayer.currentTimeProperty().addListener((obs, old, now) -> {
                if (!seekSliderDragging) {
                    double totalSecs = mediaPlayer.getTotalDuration() != null
                            ? mediaPlayer.getTotalDuration().toSeconds() : 0;
                    if (totalSecs > 0) {
                        double pct = now.toSeconds() / totalSecs * 100;
                        Platform.runLater(() -> {
                            seekSlider.setValue(pct);
                            timeLabel.setText(formatTime(now.toSeconds())
                                    + " / " + formatTime(totalSecs));
                        });
                    }
                }
            });

            // All users (host and viewers) start paused; host manually presses Play
            mediaPlayer.setOnReady(() -> {
                Platform.runLater(() ->
                    addSystemMessage("✔ Video loaded: " + f.getName()
                            + " — " + formatTime(media.getDuration().toSeconds())));
                mediaPlayer.pause();
            });

            mediaPlayer.setOnError(() ->
                Platform.runLater(() ->
                    addSystemMessage("⚠ Media error: " + mediaPlayer.getError().getMessage())));

        } catch (Exception e) {
            addSystemMessage("Could not load video: " + e.getMessage());
        }
    }

    // =====================================================
    // HOST CONTROLS (only host can trigger these)
    // =====================================================
    @FXML
    private void onPlay() {
        if (mediaPlayer == null) return;
        mediaPlayer.play();
        int secs = (int) mediaPlayer.getCurrentTime().toSeconds();
        session.send("PLAY:" + secs);
    }

    @FXML
    private void onPause() {
        if (mediaPlayer == null) return;
        mediaPlayer.pause();
        int secs = (int) mediaPlayer.getCurrentTime().toSeconds();
        session.send("PAUSE:" + secs);
    }

    @FXML
    private void onSeekStart() { seekSliderDragging = true; }

    @FXML
    private void onSeekEnd() {
        seekSliderDragging = false;
        if (mediaPlayer == null || !session.isHost()) return;
        double totalSecs = mediaPlayer.getTotalDuration().toSeconds();
        double seekTo    = seekSlider.getValue() / 100.0 * totalSecs;
        mediaPlayer.seek(Duration.seconds(seekTo));
        session.send("SEEK:" + (int) seekTo);
    }

    // =====================================================
    // CHAT
    // =====================================================
    @FXML
    private void onSendChat() {
        String text = chatInput.getText().trim();
        if (text.isEmpty()) return;
        session.send("CHAT:" + text);
        chatInput.clear();
        // NOTE: Do NOT add the message locally here.
        // The server echoes it back as CHAT:<user>:<text> to all users
        // including the sender, so it will appear via onServerMessage().
    }

    @FXML private void onReact1() { session.send("REACTION:👍"); }
    @FXML private void onReact2() { session.send("REACTION:❤️"); }
    @FXML private void onReact3() { session.send("REACTION:😂"); }
    @FXML private void onReact4() { session.send("REACTION:😮"); }
    @FXML private void onReact5() { session.send("REACTION:😢"); }

    // =====================================================
    // LEAVE ROOM
    // =====================================================
    @FXML
    private void onLeaveRoom() {
        if (mediaPlayer != null) mediaPlayer.stop();
        session.send("LEAVE");
        try { MainApp.showLobby(); }
        catch (Exception e) { e.printStackTrace(); }
    }

    // =====================================================
    // SERVER MESSAGE HANDLER
    // =====================================================

    /**
     * Called for every message received from the server.
     * Wired via session.getConnection().setListener(this::onServerMessage)
     * in initialize().
     */
    public void onServerMessage(String msg) {
        Platform.runLater(() -> {
            if (msg.startsWith("CHAT:")) {
                // CHAT:<username>:<message>  (message may contain colons)
                String[] p = msg.split(":", 3);
                if (p.length >= 3) {
                    chatList.getItems().add("[" + p[1] + "] " + p[2]);
                    chatList.scrollTo(chatList.getItems().size() - 1);
                }

            } else if (msg.startsWith("REACTION:")) {
                // REACTION:<username>:<emoji>
                String[] p = msg.split(":", 3);
                if (p.length >= 3) {
                    chatList.getItems().add(p[1] + " reacted: " + p[2]);
                    chatList.scrollTo(chatList.getItems().size() - 1);
                }

            } else if (msg.startsWith("SYNC_PLAY:")) {
                int secs = Integer.parseInt(msg.split(":")[1]);
                syncPlay(secs);

            } else if (msg.startsWith("SYNC_PAUSE:")) {
                int secs = Integer.parseInt(msg.split(":")[1]);
                syncPause(secs);

            } else if (msg.startsWith("SYNC_SEEK:")) {
                int secs = Integer.parseInt(msg.split(":")[1]);
                syncSeek(secs);

            } else if (msg.startsWith("USER_JOINED:")) {
                String user = msg.split(":", 2)[1];
                addSystemMessage("▶ " + user + " joined the room");
                updateParticipantCount();

            } else if (msg.startsWith("USER_LEFT:")) {
                String user = msg.split(":", 2)[1];
                addSystemMessage("◀ " + user + " left the room");
                updateParticipantCount();

            } else if (msg.equals("ROOM_CLOSED")) {
                addSystemMessage("⚠ The host has closed the room.");
                if (mediaPlayer != null) mediaPlayer.stop();

            } else if (msg.startsWith("OK:")) {
                // Acknowledge-only replies (OK:PLAY, OK:PAUSE, OK:SEEK, OK:LEAVE)
                // No UI action needed — suppress so they don't clutter chat
                System.out.println("[Room] Server ACK: " + msg);

            } else if (msg.startsWith("ERROR:")) {
                addSystemMessage("⚠ " + msg.substring(6));
            }
        });
    }

    // =====================================================
    // SYNC HELPERS (applied to viewers when host controls playback)
    // =====================================================
    private void syncPlay(int atSeconds) {
        if (mediaPlayer == null) return;
        mediaPlayer.seek(Duration.seconds(atSeconds));
        mediaPlayer.play();
        addSystemMessage("▶ Host resumed playback at " + formatTime(atSeconds));
    }

    private void syncPause(int atSeconds) {
        if (mediaPlayer == null) return;
        mediaPlayer.seek(Duration.seconds(atSeconds));
        mediaPlayer.pause();
        addSystemMessage("⏸ Host paused at " + formatTime(atSeconds));
    }

    private void syncSeek(int atSeconds) {
        if (mediaPlayer == null) return;
        mediaPlayer.seek(Duration.seconds(atSeconds));
        addSystemMessage("⏩ Host seeked to " + formatTime(atSeconds));
    }

    // =====================================================
    // UTILITY
    // =====================================================
    private void addSystemMessage(String text) {
        chatList.getItems().add("★ " + text);
        chatList.scrollTo(chatList.getItems().size() - 1);
    }

    private void loadChatHistory() {
        new Thread(() -> {
            var history = DatabaseAPI.getChatHistory(session.getCurrentRoomId());
            Platform.runLater(() -> {
                if (!history.isEmpty()) {
                    addSystemMessage("── Chat history ──");
                    for (var m : history) {
                        chatList.getItems().add("[" + m.getUsername() + "] " + m.getMessage());
                    }
                    addSystemMessage("── Live ──");
                    chatList.scrollTo(chatList.getItems().size() - 1);
                }
            });
        }).start();
    }

    private void updateParticipantCount() {
        new Thread(() -> {
            int count = DatabaseAPI.getParticipantCount(session.getCurrentRoomId());
            Platform.runLater(() -> participantCountLabel.setText("👥 " + count + " watching"));
        }).start();
    }

    private String formatTime(double totalSeconds) {
        int secs = (int) totalSeconds;
        int h = secs / 3600;
        int m = (secs % 3600) / 60;
        int s = secs % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, s);
        return String.format("%d:%02d", m, s);
    }
}
